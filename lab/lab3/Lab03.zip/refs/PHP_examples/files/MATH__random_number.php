<?
    $random = rand( );
    $randrange = rand(1,10);
    
    echo $random.'<br />'.$randrange;
?>